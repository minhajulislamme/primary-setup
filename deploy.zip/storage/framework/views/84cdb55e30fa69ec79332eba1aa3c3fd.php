<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Vite Assets -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans antialiased bg-white">
    <h1 class="text-center mt-20 text-green-500 text-3xl">Welcome Minhajul Islam to <?php echo e(config('app.name')); ?></h1>
    <p class="text-gray-700 text-center">Your application is now up and running!</p>
    <footer class="mt-4 text-center">
        <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
    </footer>
</body>

</html>
<?php /**PATH /var/www/resources/views/welcome.blade.php ENDPATH**/ ?>